1. Install Python if you haven't already.
2. Go to your working directory.
3. (Recommended) Create a virtual environment:
    python3 -m venv venv
    source venv/bin/activate

    .venv/Scripts/activate.ps1 -- for windows


4. Install Flask:
    pip3 install flask
5. Run the app:
    
python app.py